package com.mike.languagesassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LanguagesAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(LanguagesAssignmentApplication.class, args);
	}

}
